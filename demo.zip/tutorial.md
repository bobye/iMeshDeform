Tutorial for iMeshDeform Interface
===========================
The interface of iMeshDeform is intended to resemble open source software [Blender](http://www.blender.org/). If 
you have experiences with blender before, you will find it is pretty easy to follow our intructions. 

### Get Started
Extract demo.zip after download and go to the demo directory, and 

    ./run.sh

If the program starts its computation, then it should work properly. Otherwise please contact me to fix it. 
After several seconds of subspace computation as required, it will prompt a window with a cactus mesh displayed. 

### Mode
Basically there are two modes for displaying the mesh. One is shading mode, and another is wireframe mode. You 
can switch between this two by __TAB__ key at any time.
1. **shading mode**: view shading object and some annotated landmarks (e.g., the yellow ball marked as rotation 
center), you are to manipulate the deformable mesh at this mode.
2. **wireframe mode**: view wireframe of mesh, you are to specify the constraints at this mode.

Note that in both modes, you will also find a wired plane, which can be considered as the ground. So you are 
always aware the absolute position and orientation of object and camera.

### Navigation - shading mode
As long as you have seen the object positioned in the center of window, you might want to navigate within the 
window. 
 * **Rotation**: The navigation is pretty similar to Blender. You can hold you middle mouse button (__MMB__) and 
move to change the perspectives. This will change rotate the camera around the rotation center (the yellow ball, 
default set to the center of object) in focus.
 * **Translation**: you can hold __Shift + MMB__ and move to change the camera window horizontally and 
vertically relative to current positioning.
 * **Zoom**: You can roll the mouse __Wheel__ to zoom in and out.

### Transform - shading mode
 Transformations (translation, rotation, and scale) can be applied onto a *context* (default set to the cactus 
object). 
 
 * **Rotation**: Press __R__ and move mouse accordingly to change the orientation of the context (axis 
perpendicular to screen). Press __R__ once more to choose axes of rotation parallel to screens. Press right 
mouse button (__RMB__) to cancel operation, or press left mouse button (__LMB__) to confirm current operation.
 * **Translation**: Similar to rotation, press __G__ and move mouse, __LMB__ to confirm and __RMB__ to cancel.
 * ** Scale **: Similarly, press __S__ and move mouse, __LMB__ to confirm and __RMB__ to cancel.

### Create Constraint Handlers - wireframe mode
Now __TAB__ to wireframe mode, you can create a contraint handler by selecting a set of vertices (nonempty, at 
least one vertex). There are two ways to select vertices. 
1. Click __RMB__ near the vertex of interest, use __Shift + RMB__ for multiple selections.
2. Press __B__, and draw a rectangle indicating the region of interest (ROI)

In addition, you can reset by pressing __A__ to clear all current selections.

Once you have finished the selection of vertices, press __Shift + A__ and then press __H__ to add a constraint 
handler for the selections. You will see a blue ball is created in correspondance accordingly. Repeat above 
procedures, and create at least three constraint handlers. 

(If you want to delete your added handler, simply switch back to shading mode, right click the blue ball, and 
press __D__ to remove it.)

Then we are near done, switch back to shading mode.

### Deform the shape - shading mode
Before we deform the shape, remember to press __Shift + P__ to prepare after the specification of all constraint 
handlers. It usually only consumes less than 100ms. Once you change the onsite constraint handlers (either 
delete one or add a new one), you need to re-prepare (__Shift + P__) again.

Now in order to apply transforms to different handler, you can use __RMB__ to select one handler. This will 
change the context (from default one, the cactus object) to your selected handler. The subsequent 
transformations are then applied onto the context. For example, you can drag the blue ball by pressing __G__ and 
move, the mesh deformation results, that match the instant contraints imposed by user, are displayed 
interactively _on-the-fly_.

### _Enjoy!_

Send feedback to [bobye](https://github.com/bobye/imeshdeform).
