#!/bin/sh

# run main program
./iMeshDeform test2.off test2_cluster1.id test2_rotation.id test2_rigid.id -pc_factor_mat_solver_package umfpack

